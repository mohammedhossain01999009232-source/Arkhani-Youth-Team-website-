ARKHANI YOUTH TEAM — ROHINGYA COMEDY WEBSITE

This is a starter website template. It is not yet published online and does not earn money automatically.

FILES
- index.html: page content
- style.css: design

HOW TO CUSTOMIZE
1. Open index.html in a text editor.
2. Replace sample video cards with your real video titles and permitted embed links.
3. Replace the # links for TikTok, Facebook, and YouTube with your actual public profile links.
4. Add a public contact email if you want one.
5. Upload the files to a static hosting service to publish the site.

ADS
The ad area is a placeholder, not a live ad. Apply directly to a legitimate ad network such as Google AdSense and wait for approval. Only then add the ad code they provide. Approval is not guaranteed.
Never click your own ads, encourage visitors to click ads, or use fake traffic. Check the provider's minimum age and payment rules; if you are under 18, ask a parent/guardian to help with the account.
